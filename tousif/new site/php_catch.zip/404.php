<?
//Your email where you want 404 errors reported
$myemail="air248@yahoo.com";

//The complete domain name of your website, don't put any slashes at the end
$websiteaddress="http://www.mywebsite.com";

//Error 404 report email subject
$emailsubject="Error 404 Report";

//USER INFORMATION
//Date and time of server
$thedatetime=date("l")." ".date("F")." ".date("j")." ".date("Y")." - ".date("g").":".date("i").":".date("s")." ".date("A");
//IP Address of user
$userip=getenv("REMOTE_ADDR");
//User agent name
$useragent=getenv("HTTP_USER_AGENT");
//Page that wasn't found
$requestedfile=$websiteaddress.getenv("REQUEST_URI");
//Page that provided the broken link
$referrerpage=getenv("HTTP_REFERER");
//Set the email message
$emailmessage="Error 404 Report\r\nDate/Time: ".$thedatetime."\r\nIP Address: ".$userip."\r\nUser agent: ".$useragent."\r\nRequest page that doesn't exists: ".$requestedfile."\r\nReferrer page that contains the broken link: ".$referrerpage;
//Send the email to the custom email addresss
mail($myemail, $emailsubject, $emailmessage, "From: ".$myemail);
?>
<html>

<head>
<title><?echo $sitename;?> Page Not Found</title>
</head>

<body>

<p>&nbsp;</p>
<table border="0" cellspacing="0" width="100%" cellpadding="5"
style="border: 1 dashed #000000">
  <tr>
    <td width="100%" bgcolor="#CCCCFF"><b><font face="Arial">&nbsp;</font></b><font
      face="Arial"><i><font size="5">Page Not Found</font></i></font></td>
  </tr>
  <tr>
    <td width="100%" bgcolor="#FFFFFF"><font face="Arial" color="#0033CC"
      size="3"><b>Sorry, the page you have requested, <?echo $requestedfile;?>, doesn't exists in our website.</b></font>
      <p><font face="Arial" size="3"><b>You don't need to report this error, the
      error has been tracked and reported automatically to the webmaster</b></font>
      <font face="Arial" size="3"><b>Thanks.</b></font></p>
      <p><font face="Arial">Here is a list of our website contents:</font></p>
      <ul>
        <li><a href="index.html"><font face="Arial">Home</font></a></li>
      </ul>
    </td>
  </tr>
</table>

</body>

</html>