To install PHP Catcher on your website follow these steps:

1. Copy the 404.php file to  your website server.
2. Copy the HTACCESS file to  your website server in ACSII mode.

That's it!

For support on this script, contact the vendor from whom you purchased it from.

Copyright � 2003 SoftwareSellers.net